﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ManagerCenter.UserManager.EntityFrameworkCore.Data
{
    public class DbContextSeedData
    {
        public DbContextSeedData(ApplicationDbContext applicationDbContext)
        {
           
        }
    }
}
