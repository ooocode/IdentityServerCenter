﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ManagerCenter.UserManager.Abstractions.Dtos.UserManagerDtos
{
    public class DictionaryTypeDto
    {
        public long Id { get; set; }


        public string Name { get; set; }


        public string Remark { get; set; }
    }
}
